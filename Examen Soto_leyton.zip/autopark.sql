-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 29-11-2017 a las 19:56:19
-- Versión del servidor: 5.7.19
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `autopark`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boleta`
--

DROP TABLE IF EXISTS `boleta`;
CREATE TABLE IF NOT EXISTS `boleta` (
  `idboleta` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `descripcion` varchar(1000) NOT NULL,
  `idtipopago` int(11) NOT NULL,
  `idenvioboleta` int(11) NOT NULL,
  `rutcliente` int(11) NOT NULL,
  `idestacionamiento` int(11) NOT NULL,
  `idbol` int(11) NOT NULL,
  PRIMARY KEY (`idboleta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `boleta`
--

INSERT INTO `boleta` (`idboleta`, `total`, `descripcion`, `idtipopago`, `idenvioboleta`, `rutcliente`, `idestacionamiento`, `idbol`) VALUES
(1, 1000, 'Santa Rosa :Av. Santa Rosa, 76 ', 1, 1, 18499714, 1, 1),
(2, 2500, 'Marchant Pereira: Av. Providencia, 1971', 1, 1, 18499714, 3, 1),
(3, 3500, 'Pedro Valdivia: Av. Providencia, 2049 ', 1, 1, 18499714, 4, 1),
(4, 2500, 'Plaza de Armas: 21 de Mayo Frente al 576', 1, 1, 18499714, 6, 2),
(5, 3500, 'Pedro Valdivia: Av. Providencia, 2049 ', 1, 1, 18499714, 4, 2),
(6, 3500, 'Pedro Valdivia: Av. Providencia, 2049 ', 1, 1, 18499714, 4, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `rutcliente` int(11) NOT NULL,
  `nombrecliente` varchar(100) NOT NULL,
  `telefonocliente` int(11) NOT NULL,
  `emailcliente` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`rutcliente`, `nombrecliente`, `telefonocliente`, `emailcliente`) VALUES
(18499714, 'Ricardo', 95875633, 'rsoto@soing.cl');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `envioboleta`
--

DROP TABLE IF EXISTS `envioboleta`;
CREATE TABLE IF NOT EXISTS `envioboleta` (
  `idenvioboleta` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`idenvioboleta`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `envioboleta`
--

INSERT INTO `envioboleta` (`idenvioboleta`, `descripcion`) VALUES
(1, 'Correo electronico'),
(2, 'Direccion particular');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estacionamiento`
--

DROP TABLE IF EXISTS `estacionamiento`;
CREATE TABLE IF NOT EXISTS `estacionamiento` (
  `idestacionamiento` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`idestacionamiento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estacionamiento`
--

INSERT INTO `estacionamiento` (`idestacionamiento`, `descripcion`, `valor`) VALUES
(1, 'Santa Rosa :Av. Santa Rosa, 76 ', 1000),
(2, 'Parking VM4860 : Av. Vicuña Mackenna, 4860  ', 2000),
(3, 'Marchant Pereira: Av. Providencia, 1971', 2500),
(4, 'Pedro Valdivia: Av. Providencia, 2049 ', 3500),
(5, 'Ricardo Lyon: Av. Providencia, 2269  ', 3500),
(6, 'Plaza de Armas: 21 de Mayo Frente al 576', 2500);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tablatempcliente`
--

DROP TABLE IF EXISTS `tablatempcliente`;
CREATE TABLE IF NOT EXISTS `tablatempcliente` (
  `rutcliente` int(11) NOT NULL,
  `nombrecliente` varchar(250) NOT NULL,
  `telefono` int(11) NOT NULL,
  `mail` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tablatemporal`
--

DROP TABLE IF EXISTS `tablatemporal`;
CREATE TABLE IF NOT EXISTS `tablatemporal` (
  `idestacionamiento` int(11) NOT NULL,
  `descripcion` varchar(1000) NOT NULL,
  `valor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipopago`
--

DROP TABLE IF EXISTS `tipopago`;
CREATE TABLE IF NOT EXISTS `tipopago` (
  `idtipopago` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`idtipopago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipopago`
--

INSERT INTO `tipopago` (`idtipopago`, `descripcion`) VALUES
(1, 'Transferencia'),
(2, 'Pago en linea'),
(3, 'Orden de compra');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voucher`
--

DROP TABLE IF EXISTS `voucher`;
CREATE TABLE IF NOT EXISTS `voucher` (
  `idvoucher` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(2000) NOT NULL,
  `total` int(11) NOT NULL,
  `idboleta` int(11) NOT NULL,
  `rutcliente` int(11) NOT NULL,
  PRIMARY KEY (`idvoucher`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `voucher`
--

INSERT INTO `voucher` (`idvoucher`, `descripcion`, `total`, `idboleta`, `rutcliente`) VALUES
(2, ' Santa Rosa :Av. Santa Rosa, 76  Marchant Pereira: Av. Providencia, 1971 Pedro Valdivia: Av. Providencia, 2049  ', 7000, 1, 18499714),
(3, ' Plaza de Armas: 21 de Mayo Frente al 576 Pedro Valdivia: Av. Providencia, 2049  Pedro Valdivia: Av. Providencia, 2049  ', 9500, 2, 18499714);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
