/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import static Conexion.IObtenible.db;
import static Conexion.IObtenible.nombre;
import static Conexion.IObtenible.password;
import static Conexion.IObtenible.url;
import static Conexion.IObtenible.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Soul
 */
public class Conexion 
{
    private Connection conexion = null;
    
    public Conexion()
    {
      try
      {
       Class.forName(nombre);
       conexion = DriverManager.getConnection(url, user, password);
       
       if (conexion != null)
       {
           System.out.println("Conexión a "+ db + " exitosa");
       }
      }
      catch (SQLException ex)
      {
          System.out.println("Error de conexión: DETALLES:"+ ex.getMessage() );
      }
      catch (ClassNotFoundException ex)
      {
          System.out.println("Error con el driver: DETALLES:"+ ex.getMessage() );
      }
    }
    
    public void cerrarConexion()
    {
      if(conexion != null)
      {
         try
         {
         conexion.close();
         }
         catch(Exception ex)
         {
             System.out.println("No se pudo cerrar la conexion");
         }
      }
      
    }
    
    public Connection getConexion()
    {
      return conexion;
    }
    
}
