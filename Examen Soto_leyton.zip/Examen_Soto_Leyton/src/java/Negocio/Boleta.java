/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

/**
 *
 * @author Soul
 */
public class Boleta 
{
    private int idboleta;
    private int total;
    private String descripcion;
    private int idtipopago;
    private int idenvioboleta;
    private int rut;
    private int idest;

    public int getIdboleta() {
        return idboleta;
    }

    public void setIdboleta(int idboleta) {
        this.idboleta = idboleta;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getIdtipopago() {
        return idtipopago;
    }

    public void setIdtipopago(int idtipopago) {
        this.idtipopago = idtipopago;
    }

    public int getIdenvioboleta() {
        return idenvioboleta;
    }

    public void setIdenvioboleta(int idenvioboleta) {
        this.idenvioboleta = idenvioboleta;
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public int getIdest() {
        return idest;
    }

    public void setIdest(int idest) {
        this.idest = idest;
    }

    public Boleta() {
    }

    public Boleta(int idboleta, int total, String descripcion, int idtipopago, int idenvioboleta, int rut, int idest) {
        this.idboleta = idboleta;
        this.total = total;
        this.descripcion = descripcion;
        this.idtipopago = idtipopago;
        this.idenvioboleta = idenvioboleta;
        this.rut = rut;
        this.idest = idest;
    }

   
    
    
}
