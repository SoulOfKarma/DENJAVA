/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

/**
 *
 * @author Soul
 */
public class TipoPago 
{
  private int idtipopago;
  private String descripcion;

    public int getIdtipopago() {
        return idtipopago;
    }

    public void setIdtipopago(int idtipopago) {
        this.idtipopago = idtipopago;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoPago() {
    }

    public TipoPago(int idtipopago, String descripcion) {
        this.idtipopago = idtipopago;
        this.descripcion = descripcion;
    }
  
  
}
