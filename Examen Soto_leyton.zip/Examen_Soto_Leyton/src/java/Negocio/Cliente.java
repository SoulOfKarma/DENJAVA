/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

/**
 *
 * @author Soul
 */
public class Cliente
{
    private int rutcliente;
    private String nombrecliente;
    private int telefonocliente;
    private String mailcliente;

    public int getRutcliente() {
        return rutcliente;
    }

    public void setRutcliente(int rutcliente) {
        this.rutcliente = rutcliente;
    }

    public String getNombrecliente() {
        return nombrecliente;
    }

    public void setNombrecliente(String nombrecliente) {
        this.nombrecliente = nombrecliente;
    }

    public int getTelefonocliente() {
        return telefonocliente;
    }

    public void setTelefonocliente(int telefonocliente) {
        this.telefonocliente = telefonocliente;
    }

    public String getMailcliente() {
        return mailcliente;
    }

    public void setMailcliente(String mailcliente) {
        this.mailcliente = mailcliente;
    }

    public Cliente() {
    }

    public Cliente(int rutcliente, String nombrecliente, int telefonocliente, String mailcliente) {
        this.rutcliente = rutcliente;
        this.nombrecliente = nombrecliente;
        this.telefonocliente = telefonocliente;
        this.mailcliente = mailcliente;
    }

    
}
