/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

/**
 *
 * @author Soul
 */
public class Estacionamiento
{
    private int idest;
    private String descripcion;
    private int valor;

    public int getIdest() {
        return idest;
    }

    public void setIdest(int idest) {
        this.idest = idest;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Estacionamiento() {
    }

    public Estacionamiento(int idest, String descripcion, int valor) {
        this.idest = idest;
        this.descripcion = descripcion;
        this.valor = valor;
    }
    
    
}
