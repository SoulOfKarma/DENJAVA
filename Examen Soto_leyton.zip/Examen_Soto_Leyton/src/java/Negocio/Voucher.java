/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

/**
 *
 * @author Soul
 */
public class Voucher
{
    private int idvoucher;
    private String descripcion;
    private int total;
    private int idboleta;
    private int rutcliente;

    public int getIdvoucher() {
        return idvoucher;
    }

    public void setIdvoucher(int idvoucher) {
        this.idvoucher = idvoucher;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getIdboleta() {
        return idboleta;
    }

    public void setIdboleta(int idboleta) {
        this.idboleta = idboleta;
    }

    public int getRutcliente() {
        return rutcliente;
    }

    public void setRutcliente(int rutcliente) {
        this.rutcliente = rutcliente;
    }

    public Voucher() {
    }

    public Voucher(int idvoucher, String descripcion, int total, int idboleta, int rutcliente) {
        this.idvoucher = idvoucher;
        this.descripcion = descripcion;
        this.total = total;
        this.idboleta = idboleta;
        this.rutcliente = rutcliente;
    }
    
    
}
