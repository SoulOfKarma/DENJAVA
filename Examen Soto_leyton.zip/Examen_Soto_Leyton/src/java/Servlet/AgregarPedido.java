/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import DAO.ClienteDAO;
import DAO.EstacionamientoDAO;
import DAO.ListasDAO;
import DAO.PedidoDAO;
import DAO.VoucherDAO;
import Negocio.Cliente;
import Negocio.Envio;
import Negocio.Estacionamiento;
import Negocio.TipoPago;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.catalina.Session;

/**
 *
 * @author Soul
 */
@WebServlet(name = "AgregarPedido", urlPatterns = {"/AgregarPedido"})
public class AgregarPedido extends HttpServlet {

    private final static Logger LOGGER = Logger.getLogger("Servlet.AgregarPedido");

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // processRequest(request, response);
        ListasDAO lis = new ListasDAO();
        EstacionamientoDAO listaEst = new EstacionamientoDAO();
        List<Envio> lista = lis.listaTipoEnvio(request);
        List<TipoPago> list = lis.listaTipoPago(request);
        List<Estacionamiento> lisest = lis.listaEstacionamientos(request);
        List<Estacionamiento> listaest = listaEst.listaTemporalEst(request);
        request.setAttribute("lista", lista);
        request.setAttribute("list", list);
        request.setAttribute("lisest", lisest);
        request.setAttribute("listaest", listaest);
        HttpSession respuesta = request.getSession(true);
        ClienteDAO cli = new ClienteDAO();
        String run = request.getParameter("txtrut");
        int rut = Integer.parseInt(run);
        Cliente a = cli.retornarCliente(request, rut);
        respuesta.setAttribute("cliente", a);

        LOGGER.log(Level.INFO, "Recuperando lista de Tipo de envio de boleta,tipo de pago y estacionamiento");
        LOGGER.log(Level.INFO, "Redirigiendo a vista de pedido");
        request.getRequestDispatcher("pedidoEstacionamiento.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);
        HttpSession respuesta = request.getSession();
        Cliente as = (Cliente) respuesta.getAttribute("clie");
        String validador = request.getParameter("Agregar");
        String val = request.getParameter("btnPagar");
       String temp = " ";
        int ids = 0;
        PedidoDAO ped = new PedidoDAO();
        ids = ped.retornarIdboletaListado();
        int ruts = as.getRutcliente();
        ClienteDAO cli = new ClienteDAO();
        if (validador != null) {
            if (validador.equals("Agregar")) {

                EstacionamientoDAO est = new EstacionamientoDAO();
                est.insertarEntablatemporal(request);
                ListasDAO lis = new ListasDAO();
                EstacionamientoDAO listaEst = new EstacionamientoDAO();
                List<Envio> lista = lis.listaTipoEnvio(request);
                List<TipoPago> list = lis.listaTipoPago(request);
                List<Estacionamiento> lisest = lis.listaEstacionamientos(request);
                List<Estacionamiento> listaest = listaEst.listaTemporalEst(request);
                request.setAttribute("lista", lista);
                request.setAttribute("list", list);
                request.setAttribute("lisest", lisest);
                request.setAttribute("listaest", listaest);
                
                cli = new ClienteDAO();

                Cliente a = cli.retornarCliente(request, ruts);
                respuesta.setAttribute("cliente", a);
                request.getRequestDispatcher("pedidoEstacionamiento.jsp").forward(request, response);

            }
        } else if (val.equals("Pagar")) {
            
            EstacionamientoDAO listaEst = new EstacionamientoDAO();
            List<Estacionamiento> listaest = listaEst.listaTemporalEst(request);
            

            int cont = 0;
            int sumatotal = 0;
            for (Estacionamiento listaest1 : listaest) {
                if (cont == 0) {
                    temp = temp + listaest1.getDescripcion() + " ";
                    sumatotal = sumatotal + listaest1.getValor();
                    ped = new PedidoDAO();
                    
                    String idtipoPago = request.getParameter("rbTipoPago");
                    int idtipopago = Integer.parseInt(idtipoPago);
                    String idenvioBoleta = request.getParameter("rbEnvioBoleta");
                    int idenvioboleta = Integer.parseInt(idenvioBoleta);
                    
                
                    
                    ped.insertarBoleta(listaest1.getValor(), listaest1.getDescripcion(), idtipopago, idenvioboleta, ruts, listaest1.getIdest(),ids);
                    
                } else {
                    temp = temp + listaest1.getDescripcion() + " ";
                    sumatotal = sumatotal + listaest1.getValor();
                    ped = new PedidoDAO();
                    int idboleta = ped.retornarIdboleta();
                    String idtipoPago = request.getParameter("rbTipoPago");
                    int idtipopago = Integer.parseInt(idtipoPago);
                    String idenvioBoleta = request.getParameter("rbEnvioBoleta");
                    int idenvioboleta = Integer.parseInt(idenvioBoleta);
                    
                    ped.insertarBoletalista(idboleta, listaest1.getValor(), listaest1.getDescripcion(), idtipopago, idenvioboleta, ruts, listaest1.getIdest(),ids);
                }

                cont++;
            }
            int idboleta = ped.retornarIdboletaListado();
            VoucherDAO vou = new VoucherDAO();
            vou.insertarvoucher(temp, sumatotal, ids, ruts);
            ped.vaciarTablatemporal();
            respuesta.setAttribute("clie", as);
            response.sendRedirect("MostrarVoucher");
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
