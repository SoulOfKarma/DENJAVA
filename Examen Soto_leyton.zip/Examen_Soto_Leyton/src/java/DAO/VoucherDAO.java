/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Negocio.Boleta;
import Negocio.Cliente;
import Negocio.Estacionamiento;
import Negocio.Voucher;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Soul
 */
public class VoucherDAO
{
    private final static Logger LOGGER = Logger.getLogger("DAO.EstacionamientoDAO");
    
     public void insertarvoucher(String descripcion, int total,int idboleta, int rut) {

        Conexion conn = new Conexion();
        try {
            String sql = "INSERT INTO voucher(descripcion, total, idboleta, rutcliente) VALUES (?,?,?,?)";
            
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en cliente");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
            
            ps.setString(1, descripcion);
            ps.setInt(2, total);
            ps.setInt(3, idboleta);
            ps.setInt(4, rut);
            
            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }
     
     public int retornaridboleta(HttpServletRequest request) {
        Conexion conn = new Conexion();
       int fm = 0;
        try {
            String sql = "SELECT MAX(idboleta) FROM voucher;";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            
            LOGGER.log(Level.INFO, "Ejecutando query para retornar ID del login");
           
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                fm = rs.getInt(1);
               
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return fm;
    }
     
     public Voucher retornarVoucher(HttpServletRequest request,int rut) {
        Conexion conn = new Conexion();
        Voucher fm = null;
        try {
            String sql = "SELECT * FROM voucher WHERE idboleta = ?;";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            
            LOGGER.log(Level.INFO, "Ejecutando query para retornar ID del login");
            ps.setInt(1, rut);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                fm = new Voucher();
                fm.setIdvoucher(rs.getInt("idvoucher"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setTotal(rs.getInt("total"));
                fm.setIdboleta(rs.getInt("idboleta"));
                fm.setRutcliente(rs.getInt("rutcliente"));
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return fm;
    }
     
     public List<Boleta> listaVoucher(HttpServletRequest request,int id) {
        Conexion conn = new Conexion();
        List<Boleta> ls = new ArrayList<Boleta>();
        try {
            String sql = "select * from boleta where idbol = ?;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista de estacionamientos");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Boleta fm = new Boleta();
                fm.setIdboleta(rs.getInt("idboleta"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setTotal(rs.getInt("total"));
                fm.setIdtipopago(rs.getInt("idtipopago"));
                fm.setIdenvioboleta(rs.getInt("idenvioboleta"));
                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }
     
     public List<Voucher> listaVouchers(HttpServletRequest request,int id) {
        Conexion conn = new Conexion();
        List<Voucher> ls = new ArrayList<Voucher>();
        try {
            String sql = "select * from voucher where rutcliente = ?;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista de estacionamientos");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Voucher fm = new Voucher();
                fm.setIdvoucher(rs.getInt("idvoucher"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setTotal(rs.getInt("total"));
                fm.setIdboleta(rs.getInt("idboleta"));
                fm.setRutcliente(rs.getInt("rutcliente"));
                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }
}
