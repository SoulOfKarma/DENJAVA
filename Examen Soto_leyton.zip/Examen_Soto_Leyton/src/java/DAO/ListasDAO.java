/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Negocio.Envio;
import Negocio.Estacionamiento;
import Negocio.TipoPago;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Soul
 */
public class ListasDAO {

    private final static Logger LOGGER = Logger.getLogger("DAO.ListasDAO");

    public List<Envio> listaTipoEnvio(HttpServletRequest request) {
        Conexion conn = new Conexion();
        List<Envio> ls = new ArrayList<Envio>();
        try {
            String sql = "select * from envioboleta;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista de Tipo de Envio");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Envio fm = new Envio();
                fm.setId_envio(rs.getInt("idenvioboleta"));
                fm.setDescripcion(rs.getString("descripcion"));

                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }

    public List<TipoPago> listaTipoPago(HttpServletRequest request) {
        Conexion conn = new Conexion();
        List<TipoPago> ls = new ArrayList<TipoPago>();
        try {
            String sql = "select * from tipopago;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista de Tipo de Pago");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TipoPago fm = new TipoPago();
                fm.setIdtipopago(rs.getInt("idtipopago"));
                fm.setDescripcion(rs.getString("descripcion"));

                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }

    public List<Estacionamiento> listaEstacionamientos(HttpServletRequest request) {
        Conexion conn = new Conexion();
        List<Estacionamiento> ls = new ArrayList<Estacionamiento>();
        try {
            String sql = "select * from estacionamiento;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista de estacionamientos");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Estacionamiento fm = new Estacionamiento();
                fm.setIdest(rs.getInt("idestacionamiento"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setValor(rs.getInt("valor"));
                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }

}
