/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Negocio.Cliente;
import Negocio.Estacionamiento;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Soul
 */
public class ClienteDAO 
{
    private final static Logger LOGGER = Logger.getLogger("DAO.EstacionamientoDAO");
    
    public void insertarCliente(HttpServletRequest request) {

        Conexion conn = new Conexion();
        try {
            String sql = "INSERT INTO tablatempcliente(rutcliente, nombrecliente, telefono, mail) VALUES (?,?,?,?)";

            String val = request.getParameter("txtRut");
            int rut = Integer.parseInt(val);
            String nombre = request.getParameter("txtNombre");
            String tel = request.getParameter("txtTelefono");
            int telefono = Integer.parseInt(tel);
            String mail = request.getParameter("txtmail");
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en cliente");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
            ps.setInt(1, rut);
            ps.setString(2, nombre);
            ps.setInt(3, telefono);
            ps.setString(4, mail);
            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }
    
    public int retornarUltimoRut() {
        Conexion conn = new Conexion();
        int idtor = 0;
        try {
            String sql = "select * from cliente order by rutcliente asc limit 1";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar la ultima ID ingresada");
            while (rs.next()) {

                if (rs == null || rs.getInt(1) == 0) {
                    idtor = 1;
                } else {
                    idtor = rs.getInt("rutcliente");
                }
            }
            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }
        return idtor;
    }
    
   public Cliente retornarCliente(HttpServletRequest request,int rut) {
        Conexion conn = new Conexion();
        Cliente fm = null;
        try {
            String sql = "select * from cliente where rutcliente = ?;";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            
            LOGGER.log(Level.INFO, "Ejecutando query para retornar ID del login");
            ps.setInt(1, rut);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                fm = new Cliente();
                fm.setRutcliente(rs.getInt("rutcliente"));
                fm.setNombrecliente(rs.getString("nombrecliente"));
                fm.setTelefonocliente(rs.getInt("telefonocliente"));
                fm.setMailcliente(rs.getString("emailcliente"));
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return fm;
    }
}
