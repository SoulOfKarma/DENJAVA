/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Soul
 */
public class PedidoDAO {

    private final static Logger LOGGER = Logger.getLogger("DAO.EstacionamientoDAO");
    // se inserta el primer dato de boleta
    public void insertarBoleta(int valor, String descripcion, int idtipopago, int idenvioboleta, int rut, int idestacionamiento,int idbol) {

        Conexion conn = new Conexion();
        try {
            String sql = "INSERT INTO boleta(idboleta, total,descripcion, idtipopago, idenvioboleta, rutcliente, idestacionamiento,idbol) VALUES (?,?,?,?,?,?,?,?)";
            int id = retornarIdboleta();
          
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en cliente");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ps.setInt(2, valor);
            ps.setString(3, descripcion);
            ps.setInt(4, idtipopago);
            ps.setInt(5, idenvioboleta);
            ps.setInt(6, rut);
            ps.setInt(7, idestacionamiento);
            ps.setInt(8, idbol);
            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }
    // se inserta el listado restante de boleta si existe
     public void insertarBoletalista(int id,int valor, String descripcion, int idtipopago, int idenvioboleta, int rut, int idestacionamiento,int ids) {
         
        Conexion conn = new Conexion();
        try {
            String sql = "INSERT INTO boleta(idboleta, total,descripcion, idtipopago, idenvioboleta, rutcliente, idestacionamiento,idbol) VALUES (?,?,?,?,?,?,?,?)";
            
          
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en cliente");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ps.setInt(2, valor);
            ps.setString(3, descripcion);
            ps.setInt(4, idtipopago);
            ps.setInt(5, idenvioboleta);
            ps.setInt(6, rut);
            ps.setInt(7, idestacionamiento);
            ps.setInt(8, ids);
            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }
     
     
    
    //Se genera el primer id de boleta para su uso en la lista de insercion

    public int retornarIdboleta() {
        Conexion conn = new Conexion();
        int idtor = 0;
        try {
            String sql = "select MAX(idboleta) from boleta";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar la ultima ID ingresada");
            while (rs.next()) {
                if (rs == null || rs.getInt(1) == 0) {
                    idtor = 1;
                } else {
                    idtor = rs.getInt(1) + 1;
                }

            }
            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }
        return idtor;
    }

    // se recupera solo el ultimo id para la lista de boletas para hacerles referencia

    public int retornarIdboletaListado() {
        Conexion conn = new Conexion();
        int idtor = 0;
        try {
            String sql = "select MAX(idbol) from boleta";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar la ultima ID ingresada");
            while (rs.next()) {

                if (rs == null || rs.getInt(1) == 0) {
                    idtor = 1;
                } else {
                    idtor = rs.getInt(1)+1;
                }
            }
            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }
        return idtor;
    }
    
    
    //Se vacia tabla temporal de listado de estacionamientos
    public void vaciarTablatemporal() {

        Conexion conn = new Conexion();
        try {
            String sql = "truncate tablatemporal";
            
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en cliente");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
           
            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }
}
