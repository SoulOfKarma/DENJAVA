/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Negocio.Envio;

import Negocio.Estacionamiento;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Soul
 */
public class EstacionamientoDAO {

    private final static Logger LOGGER = Logger.getLogger("DAO.EstacionamientoDAO");

    public Estacionamiento retornarEstacionamiento(int id) {
        Conexion conn = new Conexion();
        Estacionamiento fm = null;
        int idtor = 0;
        try {
            String sql = "select * from estacionamiento where idestacionamiento = ?";
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar el estacionamiento");
            while (rs.next()) {
                fm = new Estacionamiento();

                fm.setIdest(rs.getInt("idestacionamiento"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setValor(rs.getInt("valor"));

            }
            ps.close();
            rs.close();
           

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }
        return fm;
    }

    public void insertarEntablatemporal(HttpServletRequest request) {

        Conexion conn = new Conexion();
        try {
            String sql = "insert into tablatemporal(idestacionamiento,descripcion,valor)values(?,?,?)";

            String val = request.getParameter("ddlEstacionamientos");
            int id = Integer.parseInt(val);
            Estacionamiento e = retornarEstacionamiento(id);
            LOGGER.log(Level.INFO, "Ejecutando query para insertar en tabla temporal");
            PreparedStatement ps = conn.getConexion().prepareStatement(sql);
            ps.setInt(1, e.getIdest());
            ps.setString(2, e.getDescripcion());
            ps.setInt(3, e.getValor());

            ps.execute();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al recuperar dato o al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {
            conn.cerrarConexion();
        }

    }

    public List<Estacionamiento> listaTemporalEst(HttpServletRequest request) {
        Conexion conn = new Conexion();
        List<Estacionamiento> ls = new ArrayList<Estacionamiento>();
        try {
            String sql = "select * from tablatemporal;";
            LOGGER.log(Level.INFO, "Ejecutando query para recuperar lista temporal");
            PreparedStatement ps = (PreparedStatement) conn.getConexion().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Estacionamiento fm = new Estacionamiento();
                fm.setIdest(rs.getInt("idestacionamiento"));
                fm.setDescripcion(rs.getString("descripcion"));
                fm.setValor(rs.getInt("valor"));
                ls.add(fm);
            }

            ps.close();
            rs.close();

        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error al ejecutar query");
            System.out.println(ex.getMessage());
        } finally {

            conn.cerrarConexion();

        }
        return ls;
    }
}
